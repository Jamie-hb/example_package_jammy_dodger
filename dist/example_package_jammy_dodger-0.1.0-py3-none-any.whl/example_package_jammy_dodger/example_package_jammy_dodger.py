def add_one(number: float) -> float:
        """ Adds one to a number.

            Parameters
            ----------
            number: float
                addand

            Returns
            ----------
            float
                one more than input number
        """

        return number + 1
